<template>
  <d2-container>
    <div class="header-menu-nav-container">
      <ul>
        <li v-for="i in headerNav" :key="i" class="d2-text-center">{{i}}</li>
      </ul>
    </div>
  </d2-container>
</template>

<script>
export default {
  data() {
    return {
      headerNav: ["首页", "客户管理", "数据管理", "不良处置", "填报管理"]
    };
  }
};
</script>

<style lang="scss" scoped>
.header-menu-nav-container {
  ul {
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    li {
      flex: 0 0 100px;
    }
  }
}
</style>