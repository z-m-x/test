<template>
  <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item
        v-for="item in breadList"
        :to="{path:item.path}"
        :key="item.name"
      >{{item.meta.title}}</el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>

<script>
export default {
  /* 面包屑 */
  name: "breadcrumb",
  props: {
    currentPageName: {
      required: true,
      type: String,
      default: () => ""
    }
  },
  data() {
    return {
      breadList: []
    };
  },
  created() {
    this.getBreadcrumb();
  },
  watch: {
    $route() {
      this.getBreadcrumb();
    }
  },
  methods: {
    getBreadcrumb() {
      let matched = this.$route.matched.filter(item => item.name);
      this.breadList = matched;
    }
  },
};
</script>

<style lang="scss" scoped>
</style>