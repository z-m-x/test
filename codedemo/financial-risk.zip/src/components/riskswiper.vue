<template>
  <div class="swiper">
    <swiper
      ref="mySwiper"
      :auto-update="true"
      :auto-destroy="true"
      :delete-instance-on-destroy="true"
      :cleanup-styles-on-destroy="true"
      :options="swiperOptions"
      @ready="handleSwiperReadied"
      @click-slide="handleClickSlide"
    >
      <template v-for="(currentSlide,index) in getAsyncSwiperData">
        <swiper-slide :key="index">
          <p>{{currentSlide}}</p>
        </swiper-slide>
      </template>
    </swiper>
  </div>
</template>

<script>
export default {
  /* 风险消息轮播图 */
  name: "carrousel",
  props: {
    propSwiperData: {
      required: true,
      type: Array,
      default: () => [1, 2, 3]
    }
  },
  data() {
    return {
      swiperOptions: {
        height:44,
        loop: true, //loop模式：会在原本slide前后复制若干个slide(默认一个)并在合适的时候切换
        autoHeight: true,
        autoWidth: true,
        // slidesPerGroup: 3,//定义slides的数量多少为一组
        loopedSlides: 4,
        slidesPerview: "auto", //设置slider容器能够同时显示的slides数量
        direction: "vertical",
        speed: 2000, //切换速度
        initialSlide: 0, //设定初始化时slide的索引。Swiper默认初始化时显示第一个slide，
        autoplay: {
          delay: 0 //1秒切换一次
        },
        grabCursor: true, //标覆盖Swiper时指针会变成手掌形状，拖动时指针会变成抓手形状
        slideToClickedSlide: true, //点击slide会过渡到这个slide
        observer: true, //修改swiper自己或子元素时，自动初始化swiper
        observeParents: true //修改swiper的父元素时，自动初始化swiper
      }
    };
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.$swiper;
    },
    /* 外部数据处理渲染 */
    getAsyncSwiperData() {
      return this.$props.propSwiperData;
    }
  },
  created() {},
  mounted() {
    console.log("Current Swiper instance object", this.swiper);
    // this.mySwiper.slideTo(3, 1000, false)//停止
  },
  methods: {
    handleSwiperReadied() {},
    /* 点击slide触发 */
    handleClickSlide(currentSlideIndex) {
      alert(currentSlideIndex);
    }
  }
};
</script>

<style lang="less" scoped>
.swiper {
  height: 100%;
  /deep/.swiper-container {
    height: 100%;
    .swiper-slide {
      line-height: 44px !important;
    }
  }
}
</style>