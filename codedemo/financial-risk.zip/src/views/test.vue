<template>
  <div style="width:100%;height:100%">
    <!-- 双轴图 -->
    <biaxial-figure></biaxial-figure>
    <!-- 穿透图 -->
    <tree-chart></tree-chart>
    <el-button v-permission="{action:'add'}" type="primary" @click="alert(11)">添加</el-button>
    <div>当前时间：{{nowTime|timeFormat('YYYY-MM-DD HH:mm:ss')}}</div>
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="date" label="日期" width="180">
      <!-- 插槽，传入当前的表格对象 可取当前行 -->
        <template slot-scope="scope">{{scope.row.courseType | timeFormat('YYYY-MM-DD HH:mm:ss')}}</template>
      </el-table-column>
      <el-table-column prop="name" label="姓名" width="180"></el-table-column>
      <el-table-column prop="address" label="地址"  width="180"></el-table-column>
    </el-table>
  </div>
</template>

<script>
import biaxialFigure from "./system/index/components/charts/biaxialfigure";
import treeChart from "@/components/treechart.vue";
export default {
  components: {
    biaxialFigure,
    treeChart
  },
  data() {
    return {
      nowTime: "",
      tableData: [
        {
          date: new Date().getTime(),
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: new Date().getTime(),
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄"
        },
        {
          date: new Date().getTime(),
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄"
        },
        {
          date: new Date().getTime(),
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄"
        }
      ]
    };
  },
  created() {
    /* dom指令出现loading   v-loading="loading"*/
    /* 全局全屏出现loading */
     this.loadingInstance=this.$loading({
      fullscreen:false,
      body:false,
      text:'无权限访问！请联系你的管理员，点击左上方回退按钮回退到上个页面'
    })
    let thisTime = new Date();
    this.nowTime = thisTime.getTime();
  },
  computed: {}
};
</script>

<style lang="scss" scoped>
</style>